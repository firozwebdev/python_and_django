details = ('create','read','update','delete')
print(type(details))

#access item
print('Access item: ',details[1])
print('Access item: ',details[-2])

#range
print('Range start point', details[1:])
print('Range end point', details[:3])
print('Range start and end point', details[1:3])

#update tuple
cd = list(details)
cd[1] = 'Django'
details = tuple(cd)
print('Update item: ', details)

#add item
cd = list(details)
cd.append('Python')
details = tuple(cd)
print('Add item',details)

#remove item
cd = list(details)
cd.remove('create')
details = tuple(cd)
print('Remove item:', details)