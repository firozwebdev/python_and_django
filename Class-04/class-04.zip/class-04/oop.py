class Car:
    def __init__(self,name,price,color):
        self.name = name
        self.price = price
        self.color = color

    def details(self):
        print('Car name: ', self.name, 'Car price: ', self.price, 'Car color: ', self.color)

car1 = Car('BMW',300000000,'Blue')
car2 = Car('Mercedes',700000000,'Black')
car3 = Car('Audi',100000000,'Red')
car1.details()
car2.details()
car3.details()