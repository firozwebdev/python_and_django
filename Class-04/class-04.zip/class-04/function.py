def first_function():
    print('Welcome to function topics')
first_function()
first_function()
first_function()

#using parameter
def additon(x,y):
    c = x+y
    print(c)
additon(10,5)
first_function()
additon(10,50)

#print outside function
def calculator(x,y):
    c = x+y
    d = x-y
    e = x*y
    f = x/y
    return c,d,e,f
sum,sub,mul,div = calculator(10,5)
print('sum:',sum,'sub:',sub,'mul:',mul,'div:',div)
