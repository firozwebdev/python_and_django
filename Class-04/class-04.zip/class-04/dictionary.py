dict = {'python':4, 'ML':22, 'DL':'aiQuest'}
print(type(dict))
#value access using key
x = dict['python']
print(x)

#get() method
y = dict.get('DL')
print('value access using get: ', y)

#keys()
z = dict.keys()
print('Key: ',z)

#value
u = dict.values()
print('Values ',u)

#Adding item
dict['DA']=22
print('Adding item: ', dict)

#update
dict.update({'ML':'Reshedul Alam'})
print('udate data: ', dict)

#pop
dict.pop('DL')
print(dict)