duration = {2,5,9,7,55,1,2,2,2,1,1}
print(type(duration))

#Not allow duplicate value
print('Not allow duplicate value: ', duration)

#access item
#ex:1
for x in duration:
    print('Access item: ', x)

#ex:2
print('Access item: ', 550 in duration)

#add
duration.add(150)
print('Add item: ', duration)

#discard
duration.discard(777)
print('Discard method:', duration)

#del keyword
#del duration
#print('Delete set', duration)

#set union
a = {1,2,3,4,6}
b = {4,5,6,7,8,9}
print('Union method: ', a | b)

#set intersection
c = {1,2,3,4,6}
d = {4,5,6,7,8,9}
print('Set intersection: ', c & d)