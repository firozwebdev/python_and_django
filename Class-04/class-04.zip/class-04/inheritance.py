class A:
    def detail(self):
        print('Studymart')
    def details(self):
        print('Studymart2')

class B(A):
    def chd(self):
        print('Studymart3')
    def chds(self):
        print('Studymart4')

a = A()
a.detail()
a.details()

b = B()
b.detail()
b.chds()
